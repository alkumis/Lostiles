public enum Colour
{
    Green,
    Purple,
    Red,
    Yellow
}