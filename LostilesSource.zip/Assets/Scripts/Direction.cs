public enum Direction
{
    Left,
    Right,
    Down,
    Up
}